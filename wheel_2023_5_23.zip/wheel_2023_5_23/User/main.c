#include "DSP2833x_Device.h"     // DSP2833x Headerfile Include File
#include "DSP2833x_Examples.h"   // DSP2833x Examples Include File
#include "leds.h"
#include "time.h"
#include "oled.h"
#include "exti.h"
#include "stdio.h"
#include "eqep.h"

#define FLASH_RUN 1
#define SRAM_RUN 2
#define RUN_TYPE SRAM_RUN
//#if RUN_TYPE==FLASH_RUN
//extern Uint16 RamfuncsLoadStart;
//extern Uint16 RamfuncsLoadEnd;
//extern Uint16 RamfuncsRunStart;
//#endif


int va = 0;

void DELAY_MS(int b)
{
   int a;
   while(b)
   {

          for(a=0;a<1000;a++)
          {
              DELAY_US(1);
          }
          b--;
   }

}



void main()
{
    #if RUN_TYPE==FLASH_RUN
        MemCopy(&RamfuncsLoadStart, &RamfuncsLoadEnd, &RamfuncsRunStart);
        InitFlash();
    #endif
    InitSysCtrl();
    //��ʼ��PIE���ƼĴ�����PIE�ж�������
    InitPieCtrl();
    IER = 0x0000;
    IFR = 0x0000;
    InitPieVectTable();
    LED_Init();
    EXTI_Init();
    OLED_Init();
    OLED_Clear();
    EQEP1_Init();
    if(1)
    {
        OLED_DisShowCHinese(56,5,2);
        OLED_DisShowCHinese(74,5,3);
        OLED_DisShowCHinese(92,5,4);
        OLED_ShowString(0,0,"freq:150kHz",16);
        OLED_ShowString(90,0,"IO0",16);
        OLED_ShowString(0,2,"duty:",16);
        OLED_ShowNum(70,2,va,2,2,16);
        OLED_ShowString(0,4,"K1/K2",16);
        OLED_ShowString(0,6,"10/1",16);
    }

    while (1)
    {
        EPwm1B_SetCompare(150*va);
        EPwm1A_SetCompare(150*va);
    }

}
