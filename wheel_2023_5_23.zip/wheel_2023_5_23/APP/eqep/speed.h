/*
 * speed.h
 *
 *  Created on: 2023��4��16��
 *      Author: gy
 */

#ifndef APP_EQEP_SPEED_H_
#define APP_EQEP_SPEED_H_

#include "IQmathLib.h"         // Include header for IQmath library

//���������Ϣ:���������ٱ�
#define lin_number      13
#define raduction_ratio     20
#define pulse_count     1040    //һȦQPOSCNT��1040
#define set_SpeedScaler   319602

typedef struct {
                int DirectionQep;       // Output: Motor rotation direction (Q0)
                int QEP_cnt_idx;        // Variable: Encoder counter index (Q0)
                int pole_pairs;         // Parameter: Number of pole pairs (Q0)
                int index_sync_flag;    // Output: Index sync status (Q0)

                Uint32 SpeedScaler;     // Parameter :  Scaler converting 1/N cycles to a GLOBAL_Q speed (Q0) - independently with global Q
                _iq Speed_pr;           // Output :  speed in per-unit
                float BaseRpm;         // BaseRpm=60/(1040*0.01)
                _iq BaseRpm_Q;         //BaseRpm_Q=60*2^15=189046  (Q15)
                int32 SpeedRpm_pr;      // Output : speed in r.p.m. (Q0) - independently with global Q

                int Pos_increment;
                int  oldpos;            // Input: Electrical angle (pu)
                float Speed_fr;           // Output :  speed in per-unit
                float SpeedQ_fr;      // Output : Speed in rpm  (Q0) - independently with global Q
                void (*init)();         // Pointer to the init funcion
                void (*calc)();         // Pointer to the calc funtion
                }  POSSPEED;

/*-----------------------------------------------------------------------------
Define a POSSPEED_handle
-----------------------------------------------------------------------------*/
typedef POSSPEED *POSSPEED_handle;

/*-----------------------------------------------------------------------------
Default initializer for the POSSPEED Object.
-----------------------------------------------------------------------------*/
/*���\���������Ӷ��д���*/
#if (CPU_FRQ_150MHZ)
  #define POSSPEED_DEFAULTS {0x0,0x0,2,0x0,\
        set_SpeedScaler,0,5.76923076923,189046,0,\
        0,0,0,0,\
        (void (*)(long))POSSPEED_Init,\
        (void (*)(long))POSSPEED_Calc }
#endif
#if (CPU_FRQ_100MHZ)
  #define POSSPEED_DEFAULTS {0x0,0x0,2,0x0,\
        2*set_SpeedScaler/3,0,5.76923076923,189046,0,\
        0,0,0,0,\
        (void (*)(long))POSSPEED_Init,\
        (void (*)(long))POSSPEED_Calc }
#endif

void POSSPEED_Init(void);
void POSSPEED_Calc(POSSPEED_handle);

#endif /* APP_EQEP_SPEED_H_ */
