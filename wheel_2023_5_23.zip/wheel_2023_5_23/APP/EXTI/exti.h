#ifndef EXTI_H_
#define EXTI_H_
#include "leds.h"
#include "DSP2833x_Device.h"     // DSP2833x Headerfile Include File
#include "DSP2833x_Examples.h"   // DSP2833x Examples Include File
void EXTI_Init(void);
extern int va;
#endif /* APP_EXTI_EXTI_H_ */
